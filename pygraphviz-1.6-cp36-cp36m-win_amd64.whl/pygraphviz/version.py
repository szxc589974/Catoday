"""
Version information for PyGraphviz, created during installation.

Do not add this file to the repository.

"""

__version__ = '1.6'
__revision__ = None
__date__ = 'Wed Aug  5 19:03:37 2020'

